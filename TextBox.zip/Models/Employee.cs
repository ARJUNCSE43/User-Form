﻿namespace HTML_HELPER.Models
{public class UserModel
        {
            public string Name { get; set; }
            public string Email { get; set; }
            public int CountryId { get; set; } // This will be bound to the dropdown
        }
    

}