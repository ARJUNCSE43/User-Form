using HTML_HELPER.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
namespace HTML_HELPER.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            var countries = new List<SelectListItem>
            {
                new SelectListItem { Text = "United States", Value = "1" },
                new SelectListItem { Text = "Canada", Value = "2" },
                new SelectListItem { Text = "United Kingdom", Value = "3" },
                new SelectListItem { Text = "Australia", Value = "4" }
            };

            // Pass the list of countries to the view
            ViewData["Countries"] = countries;

            return View();
        }

        [HttpPost]
        public IActionResult Index(UserModel model)
        {
            if (ModelState.IsValid)
            {
                // Process the form data
                ViewBag.Message = "Form submitted successfully!";
            }

            return View(model);
        }

    }
    
}